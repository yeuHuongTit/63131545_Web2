package com.example.QLBH_ABC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QlbhAbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
