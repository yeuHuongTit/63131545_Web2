package tridm.FormSubmit_Thymeleaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormSubmitThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
