package thiGK.ntu63131545.diemMinhTri_qlsv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiemMinhTriQlsvApplicationTests {

	@Test
	void contextLoads() {
	}

}
