package thiGK.ntu63131545.diemMinhTri_qlsv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiemMinhTriQlsvApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiemMinhTriQlsvApplication.class, args);
	}

}
