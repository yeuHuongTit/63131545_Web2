tinymce.addI18n('cs_CZ',{
	'HTML source code': 'Zdrojový HTML kód',
	'Start search': 'Hledat',
	'Find next': 'Najít další',
	'Find previous': 'Najít předchozí',
	'Replace': 'Nahradit',
	'Replace all': 'Nahradit vše'
});
